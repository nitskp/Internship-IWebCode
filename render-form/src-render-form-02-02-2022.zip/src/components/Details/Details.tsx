import React from "react";

const Details = (props: { isText: boolean; fields: any[] }) => {
  const isText = props.isText;
  const fields = props.fields;
  console.log(fields);
  //wo input field mein without input waale bhi le rha hai, jiski wajah se problem aa rhi hai
  return (
    <div>
      {/* {fields.map((ele, indx) => {
        if (isText) {
          return <div>It's text</div>;
        } else {
          return <div key={"Details" + indx.toString()}>{"hello"}</div>;
        }
      })} */}
    </div>
  );
};

export default Details;
