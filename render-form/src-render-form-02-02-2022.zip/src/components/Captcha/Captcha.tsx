import React from 'react'

const Captcha = () => {
  return (
    <div className='captcha-container'>
      Captcha - It's needs to be an embedd webpage.Use Iframe. Will do later.
    </div>
  )
}

export default Captcha
