import React from 'react'

const SubmitButton = () => {
  return (
    <div className='submit-button-container'>
      <input type="submit" value="Submit Application" />
    </div>
  )
}

export default SubmitButton
