import React from 'react'

const Link = (props:{linkName:string}) => {
    const linkName = props.linkName;
  return (
      <a href='#'>{linkName}</a>
  
  )
}

export default Link
