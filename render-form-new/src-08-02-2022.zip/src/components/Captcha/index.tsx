
import Captcha from './Captcha'

const index = () => {
  return (
    <Captcha />
  )
}

export default index
