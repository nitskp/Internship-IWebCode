import Form from './Form'

const index = () => {
  return (
    <Form />
  )
}

export default index
