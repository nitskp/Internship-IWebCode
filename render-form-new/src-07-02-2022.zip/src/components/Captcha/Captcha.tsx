

const Captcha = () => {
  return (
    <div className='captcha-container'>
      Captcha
    </div>
  )
}

export default Captcha
